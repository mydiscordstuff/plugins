({default:(function(){
  'use strict';
  // Independent mobile QuestUI implementation inspired by Herzchens/QuestUI.
  // No token access, external requests, game spoofing or background claim.
  var host=null, React=null, RN=null, unsubs=[], settingsApi=null, settingsStore=null;
  var state={questStore:null, questActions:null, lastError:''};
  var C={bg:'#000000',surface:'#19050A',border:'#4B1523',accent:'#CE5265',text:'#F2B2BF',muted:'#BA7D89',success:'#59D08A'};
  var defaults={hidden:{},sort:'recommended',showExpired:false};
  function h(tag,props){if(!React||!React.createElement)return null;return React.createElement.apply(React,arguments);}
  function el(tag,props){return h.apply(null,arguments);}
  function safe(x){return x&&typeof x==='object'?x:{};}
  function lookup(names){
    try{var f=host&&host.modules&&host.modules.finders;if(!f)return null;
      for(var i=0;i<names.length;i++){var filter=f.filters&&f.filters.withProps&&f.filters.withProps.apply(null,names[i]);var list=filter&&f.lookupModule&&f.lookupModule(filter);var found=Array.isArray(list)&&list[0];if(found)return found.default&&names[i].every(function(n){return typeof found.default[n]!=='undefined';})?found.default:found;}
    }catch(_){}return null;
  }
  function stores(){return host&&host.discord&&host.discord.flux&&host.discord.flux.Stores||{};}
  function accountId(){try{var s=stores().UserStore;return s&&s.getCurrentUser&&s.getCurrentUser().id||'guest';}catch(_){return 'guest';}}
  function questStore(){return stores().QuestsStore||state.questStore||lookup([['getQuest','getQuestConfig']]);}
  function actions(){return state.questActions||lookup([['enrollInQuest','claimQuestReward'],['updateVideoProgress','enrollInQuest'],['fetchCurrentQuests']]);}
  function asArray(v){if(v instanceof Map)return Array.from(v.values());if(Array.isArray(v))return v;return v&&typeof v==='object'?Object.values(v):[];}
  function dt(x){var v=Date.parse(x||'');return Number.isFinite(v)?v:0;}
  function norm(entry){
    if(!entry||typeof entry.id!=='string'||!entry.config)return null;
    var cfg=safe(entry.config),st=safe(entry.userStatus||entry.user_status),msg=safe(cfg.messages),taskCfg=safe(cfg.taskConfigV2||cfg.task_config_v2||cfg.taskConfig||cfg.task_config),tasksCfg=safe(taskCfg.tasks),progress=safe(st.progress);
    var expiry=dt(cfg.expiresAt||cfg.expires_at), claimed=!!(st.claimedAt||st.claimed_at),completed=!!(st.completedAt||st.completed_at),enrolled=!!(st.enrolledAt||st.enrolled_at);
    var status=claimed?'claimed':completed?'ready':expiry&&expiry<Date.now()?'expired':enrolled?'active':'available';
    var tasks=Object.keys(tasksCfg).map(function(name){var t=safe(tasksCfg[name]),target=Number(t.target||0),v=progress[name],done=Number((v&&typeof v==='object'?v.value:v)||0);return {name:name,target:target,progress:done};}).filter(function(t){return t.target>0;});
    var orb=0;var rewardList=asArray(cfg.rewards||entry.rewards);rewardList.forEach(function(r){var o=safe(r);if(/ORB/i.test(String(o.type||o.rewardType||'')))orb+=Number(o.orbQuantity||o.amount||o.quantity||0)||0;});
    return {id:entry.id,name:String(msg.questName||msg.quest_name||cfg.application&&cfg.application.name||entry.id),status:status,expires:expiry,tasks:tasks,orbs:orb};
  }
  function quests(){var s=questStore();if(!s)return null;var m=new Map();asArray(s.claimedQuests).concat(asArray(s.quests)).forEach(function(q){var n=norm(q);if(n)m.set(n.id,n);});return Array.from(m.values());}
  function configure(api){settingsStore=api&&api.jsonStorage||settingsStore;}
  function conf(){var c=settingsStore&&settingsStore.cache||{};return {hidden:safe(c.hidden),sort:c.sort||'recommended',showExpired:!!c.showExpired};}
  function save(patch){if(settingsStore&&typeof settingsStore.set==='function')return settingsStore.set(patch);}
  function report(error){state.lastError=String(error&&error.message||error);}
  async function updateQuests(){var a=actions();if(a&&typeof a.fetchCurrentQuests==='function')await a.fetchCurrentQuests();}
  async function action(kind,q){var a=actions();if(!a)throw new Error('Abra a página de Missões do Discord e tente novamente.');
    if(kind==='accept'){if(typeof a.enrollInQuest!=='function')throw new Error('Ação de aceitar indisponível.');await a.enrollInQuest(q.id);}
    else if(kind==='claim'){if(typeof a.claimQuestReward!=='function')throw new Error('Ação de resgatar indisponível.');await a.claimQuestReward(q.id);}
    await updateQuests().catch(function(){});
  }
  function nativeAlerts(title,body){try{RN.Alert.alert(title,body);}catch(_){} }
  function register(){
    settingsApi=host.discord&&host.discord.modules&&host.discord.modules.settings;
    if(!settingsApi||!settingsApi.registerSettingsItem)return;
    function install(){try{
      var id='mydiscordstuff.questsui.mobile';
      unsubs.push(settingsApi.registerSettingsItem(id,{parent:null,type:'pressable',useTitle:function(){return 'QuestUI • Missões';},useDescription:function(){return 'Dashboard, progresso, filtros e recompensas';},IconComponent:function(){return h(RN.Text,{style:{color:C.accent,fontSize:24}},'✦');},onPress:openSheet}));
      unsubs.push(settingsApi.addSettingsItemToSection('VALENCED',id));
      if(settingsApi.refreshSettings)settingsApi.refreshSettings();
    }catch(e){report(e);}}
    if(settingsApi.onSettingsModulesLoaded)unsubs.push(settingsApi.onSettingsModulesLoaded(install));else install();
  }
  function text(str,style){return h(RN.Text,{style:Object.assign({color:C.text,fontSize:14},style||{})},String(str));}
  function press(label,cb,kind){return h(RN.Pressable,{onPress:cb,style:{paddingVertical:11,paddingHorizontal:14,marginTop:7,borderRadius:11,backgroundColor:kind==='solid'?'#6E1428':C.surface,borderWidth:1,borderColor:C.border}},text(label,{textAlign:'center',fontWeight:'700'}));}
  function Dashboard(){
    var r=React.useState(0),tick=r[1],er=React.useState(''),error=er[0],setError=er[1],sel=React.useState('all'),filter=sel[0],setFilter=sel[1];
    React.useEffect(function(){var id=setInterval(function(){tick(function(v){return v+1;});},4000);updateQuests().catch(function(e){setError(String(e.message||e));});return function(){clearInterval(id);};},[]);
    var all=quests(),c=conf(),owner=accountId(),hidden=Array.isArray(c.hidden[owner])?c.hidden[owner]:[];
    var counts={available:0,active:0,ready:0,claimed:0,expired:0};(all||[]).forEach(function(q){counts[q.status]++;});
    var shown=(all||[]).filter(function(q){return hidden.indexOf(q.id)<0&&(filter==='all'||q.status===filter)&&(c.showExpired||q.status!=='expired');});
    if(c.sort==='expiry')shown.sort(function(a,b){return (a.expires||Infinity)-(b.expires||Infinity);});
    else if(c.sort==='name')shown.sort(function(a,b){return a.name.localeCompare(b.name);});
    else shown.sort(function(a,b){var order={ready:0,active:1,available:2,claimed:3,expired:4};return order[a.status]-order[b.status];});
    function run(kind,q){try{RN.Alert.alert(kind==='accept'?'Aceitar missão?':'Resgatar recompensa?',q.name,[{text:'Cancelar',style:'cancel'},{text:'Confirmar',onPress:function(){action(kind,q).then(function(){tick(function(v){return v+1;});}).catch(function(e){setError(String(e.message||e));});}}]);}catch(e){setError(String(e.message||e));}}
    function hide(q){var next=hidden.includes(q.id)?hidden.filter(function(id){return id!==q.id;}):hidden.concat([q.id]);save({hidden:Object.assign({},c.hidden,{[owner]:next})});tick(function(v){return v+1;});}
    var s={flex:1,backgroundColor:C.bg},children=[];
    children.push(text('QuestUI • Mobile',{fontSize:24,fontWeight:'bold',marginBottom:6}));
    children.push(text('Disponíveis '+counts.available+'  ·  Andamento '+counts.active+'  ·  Prontas '+counts.ready,{fontSize:12,color:C.muted,marginBottom:8}));
    children.push(text('Resgatadas '+counts.claimed+'  ·  Expiradas '+counts.expired+'  ·  Ocultas '+hidden.length,{fontSize:12,color:C.muted,marginBottom:14}));
    children.push(h(RN.View,{style:{flexDirection:'row',flexWrap:'wrap',gap:5}},...['all','available','active','ready','claimed'].map(function(key){return h(RN.Pressable,{key:key,onPress:function(){setFilter(key);},style:{padding:7,paddingHorizontal:10,borderRadius:9,borderWidth:1,borderColor:filter===key?C.accent:C.border}},text(({all:'Todas',available:'Novas',active:'Ativas',ready:'Prontas',claimed:'Resgatadas'})[key],{fontSize:12}));})));
    children.push(press('↻ Atualizar missões',function(){updateQuests().then(function(){setError('');tick(function(v){return v+1;});}).catch(function(e){setError(String(e.message||e));});},'solid'));
    children.push(press('Ordenar: '+({expiry:'Expiração',name:'Nome',recommended:'Prioridade'})[c.sort],function(){save({sort:c.sort==='recommended'?'expiry':c.sort==='expiry'?'name':'recommended'});tick(function(v){return v+1;});}));
    children.push(press(c.showExpired?'Ocultar expiradas':'Mostrar expiradas',function(){save({showExpired:!c.showExpired});tick(function(v){return v+1;});}));
    if(!all)children.push(text('QuestStore indisponível. Abra Missões no Discord primeiro.',{color:'#FFBD9B',padding:12}));
    else if(shown.length===0)children.push(text('Nenhuma missão neste filtro.',{padding:16,color:C.muted}));
    if(error||state.lastError)children.push(text(error||state.lastError,{color:'#F8A27B',paddingTop:8}));
    shown.slice(0,100).forEach(function(q){var lines=[q.status.toUpperCase()];q.tasks.forEach(function(t){lines.push(t.name.replace(/_/g,' ')+' '+Math.floor(Math.min(t.progress,t.target))+'/'+Math.floor(t.target)+' ('+Math.floor(Math.min(100,100*t.progress/t.target))+'%)');});if(q.orbs)lines.push(q.orbs+' Orbs');if(q.expires)lines.push('Até '+new Date(q.expires).toLocaleDateString('pt-BR'));
      children.push(h(RN.View,{key:q.id,style:{padding:13,marginTop:12,backgroundColor:C.surface,borderWidth:1,borderColor:C.border,borderRadius:13}},text(q.name,{fontWeight:'700',fontSize:16}),text(lines.join(' • '),{color:C.muted,fontSize:12,marginTop:5}),q.status==='available'?press('Aceitar missão',function(){run('accept',q);},'solid'):null,q.status==='ready'?press('Resgatar recompensa',function(){run('claim',q);},'solid'):null,press(hidden.indexOf(q.id)<0?'Ocultar do painel':'Mostrar no painel',function(){hide(q);})));});
    var bridge=globalThis.__mydiscordstuffOrionMobileBridge;if(bridge&&typeof bridge.getState==='function'){
      var bs=bridge.getState();
      children.unshift(text('Orion Mobile: '+(bs.status||'parado')+' • '+(bs.message||''),{color:C.muted,fontSize:12,marginBottom:10}));
      children.push(text('Controles do OrionQuests Mobile',{fontSize:17,fontWeight:'bold',marginTop:16}));
      children.push(press(bs.status==='pausado'?'▶ Retomar Orion':'▶ Iniciar Orion',function(){
        try{RN.Alert.alert('Automação de quests: risco à conta','O Discord pode restringir missões ou aplicar medidas à sua conta. O Orion Mobile só tenta vídeos e exige o Discord aberto. Continuar?',[
          {text:'Cancelar',style:'cancel'},
          {text:'Concordo',onPress:function(){if(bs.status==='pausado')bridge.resume();else bridge.start();tick(function(v){return v+1;});}}
        ]);}catch(e){setError(String(e.message||e));}
      },'solid'));
      children.push(press('⏸ Pausar Orion',function(){bridge.pause();tick(function(v){return v+1;});}));
      children.push(press('■ Parar Orion',function(){bridge.stop();tick(function(v){return v+1;});}));
    }
    return h(RN.ScrollView,{style:s,contentContainerStyle:{padding:16,paddingBottom:48},keyboardShouldPersistTaps:'handled'},...children);
  }
  function SettingsComponent(props){configure(props&&props.api);return h(Dashboard,{});}
  function openSheet(){try{var a=host.discord.actions.ActionSheetActionCreators,d=host.discord.design.Design;if(a&&a.openLazy&&d&&d.ActionSheet){function Sheet(){return h(d.ActionSheet,{header:d.BottomSheetTitleHeader?h(d.BottomSheetTitleHeader,{title:'QuestUI • Missões'}):null},h(Dashboard,{}));}a.openLazy(Promise.resolve({default:Sheet}),'mydiscordstuff.questui.sheet',{});return;}}catch(e){report(e);}nativeAlerts('QuestUI','Abra Plugins → QuestUI → Configurações para ver o painel de missões.');}
  return plugin({jsonStorage:{load:true,default:defaults},start:function(api){host=valenced;React=host.react&&host.react.React;RN=host.react&&host.react.ReactNative;configure(api);if(!React||!RN)throw Error('React Native não disponível');register();if(api.cleanup)api.cleanup(function(){while(unsubs.length){try{unsubs.pop()();}catch(_){}}});},stop:function(){while(unsubs.length){try{unsubs.pop()();}catch(_){}}},SettingsComponent:SettingsComponent});
})()})
