(function () {
"use strict";
/**
 * Platform Indicators for Valenced — experimental v0.1.0
 * Port inspired by MSMA's Vendetta PlatformIndicators.
 * Does not make network requests or send presence data anywhere.
 *
 * All Discord-internal patches are guarded. UI component names/layouts
 * differ by Discord build, so individual display locations may not patch.
 */









const DEFAULTS = {
  dmList: true,
  memberList: true,
  profiles: true,
  crimsonIcons: false,
  showOffline: false,
}

const PLATFORMS = [
  ['desktop', '▣', 'Desktop'],
  ['web', '◎', 'Web browser'],
  ['mobile', '▯', 'Mobile'],
  ['embedded', '⬡', 'Console / embedded'],
  ['vr', '◇', 'Virtual reality'],
]

const STATUS_COLORS = {
  online: '#43B581',
  idle: '#F0B232',
  dnd: '#F23F43',
  invisible: '#80848E',
  offline: '#80848E',
}

const MARKER = 'mydiscordstuff-platform-indicators'
let settingsApi

function getStore(name) {
  try { return valenced.discord.flux.Stores?.[name] } catch { return undefined }
}

function getUserStatuses(userId) {
  if (!userId) return {}
  const presence = getStore('PresenceStore')
  const sessions = getStore('SessionsStore')
  const users = getStore('UserStore')
  let currentId
  try { currentId = users?.getCurrentUser?.()?.id } catch {}

  // Discord's own connected sessions have a separate store.
  if (userId === currentId && sessions) {
    try {
      const entries = Object.values(sessions.getSessions?.() ?? {})
      const own = {}
      for (const session of entries) {
        const platform = session?.clientInfo?.client
        if (platform && platform !== 'unknown' && session?.status)
          own[platform] = session.status
      }
      if (Object.keys(own).length) return own
    } catch {}
  }

  try {
    // Original Vendetta plugin's presence source, with additional API fallbacks.
    const state = presence?.getState?.()
    const fromState = state?.clientStatuses?.[userId]
      ?? state?.clientStatuses?.get?.(userId)
    const fromMethod = presence?.getClientStatuses?.(userId)
    const found = fromState ?? fromMethod
    return found && typeof found === 'object' ? found : {}
  } catch { return {} }
}

function toSnapshot(userId) {
  const raw = getUserStatuses(userId)
  const visible = {}
  for (const [platform] of PLATFORMS) {
    const status = raw?.[platform]
    if (typeof status === 'string') visible[platform] = status
  }
  return JSON.stringify(visible)
}

function subscribeToPresence(onChange) {
  const unsubs = []
  for (const store of [getStore('PresenceStore'), getStore('SessionsStore')]) {
    try {
      if (typeof store?.addChangeListener === 'function') {
        store.addChangeListener(onChange)
        unsubs.push(() => store.removeChangeListener?.(onChange))
      }
    } catch {}
  }
  return () => { for (const dispose of unsubs) { try { dispose() } catch {} } }
}

function PlatformIcons({ userId }) {
  const settings = settingsApi?.use?.() ?? DEFAULTS
  const snap = valenced.react.React.useCallback(() => toSnapshot(userId), [userId])
  const snapshot = valenced.react.React.useSyncExternalStore(subscribeToPresence, snap, snap)
  let statuses
  try { statuses = JSON.parse(snapshot) } catch { statuses = {} }
  const icons = PLATFORMS.filter(([platform]) => {
    const value = statuses[platform]
    return value && (settings.showOffline || (value !== 'offline' && value !== 'invisible'))
  })
  if (!icons.length) return null

  return valenced.react.React.createElement(
    valenced.react.ReactNative.View,
    { style: { flexDirection: 'row', alignItems: 'center', marginLeft: 5, flexShrink: 0 },
      accessibilityLabel: icons.map(([p, , name]) => `${name}: ${statuses[p]}`).join(', ') },
    ...icons.map(([platform, symbol, name]) => valenced.react.React.createElement(valenced.react.ReactNative.Text, {
      key: `${MARKER}-${platform}`,
      accessible: true,
      accessibilityLabel: `${name}: ${statuses[platform]}`,
      style: {
        color: settings.crimsonIcons ? '#B92440' : (STATUS_COLORS[statuses[platform]] ?? '#B4BAC2'),
        fontSize: 15,
        fontWeight: '700',
        marginHorizontal: 2,
        includeFontPadding: false,
      },
    }, symbol)),
  )
}

function badge(id) {
  return valenced.react.React.createElement(PlatformIcons, { key: MARKER, userId: id })
}

function rowWithBadge(content, userId) {
  return valenced.react.React.createElement(valenced.react.ReactNative.View, {
    style: { flexDirection: 'row', alignItems: 'center', flexShrink: 1 },
  }, content, badge(userId))
}

// Immutable tree editing: Discord caches many React element trees.
function replaceFirst(root, predicate, replace, depth = 0) {
  if (!valenced.react.React.isValidElement(root) || depth > 24) return root
  if (predicate(root)) return replace(root)
  const oldChildren = root.props?.children
  if (Array.isArray(oldChildren)) {
    for (let i = 0; i < oldChildren.length; i++) {
      const updated = replaceFirst(oldChildren[i], predicate, replace, depth + 1)
      if (updated !== oldChildren[i]) {
        const children = [...oldChildren]
        children[i] = updated
        return valenced.react.React.cloneElement(root, { children })
      }
    }
  } else if (valenced.react.React.isValidElement(oldChildren)) {
    const updated = replaceFirst(oldChildren, predicate, replace, depth + 1)
    if (updated !== oldChildren) return valenced.react.React.cloneElement(root, { children: updated })
  }
  return root
}

function insertDmBadge(tree, userId) {
  if (!userId) return tree
  return replaceFirst(
    tree,
    node => Array.isArray(node.props?.children)
      && node.props.children.some(ch => valenced.react.React.isValidElement(ch)
        && (ch.props?.ellipsizeMode || ch.props?.numberOfLines === 1)
        && typeof ch.props?.children === 'string'),
    node => {
      const children = [...node.props.children]
      const index = children.findIndex(ch => valenced.react.React.isValidElement(ch)
        && (ch.props?.ellipsizeMode || ch.props?.numberOfLines === 1)
        && typeof ch.props?.children === 'string')
      if (index < 0) return node
      children[index] = rowWithBadge(children[index], userId)
      return valenced.react.React.cloneElement(node, { children })
    },
  )
}

function insertMemberBadge(tree, props) {
  const id = props?.user?.id
  if (!id || !valenced.react.React.isValidElement(tree) || !tree.props?.label) return tree
  return valenced.react.React.cloneElement(tree, { label: rowWithBadge(tree.props.label, id) })
}

// Name filter for React.memo(function UserRow() {}) components.
// Unlike a hand-built filter, this uses Valenced's documented filter factory.
const buildMemoName = () => valenced.modules.finders.filters.createFilterGenerator(
  ([name], id, exports) => exports?.type?.name === name,
  ([name]) => `${MARKER}.memo-name(${name})`,
)

function attachMemoPatch(target, apply, register, patched, logger) {
  if (!target || patched.has(target)) return
  const method = typeof target.type === 'function' ? 'type'
    : typeof target.render === 'function' ? 'render' : null
  if (!method) return
  try {
    // Valenced's `after` receives only the return value; capture render props
    // in a `before` hook (both are synchronous for these render functions).
    let lastProps
    register(valenced.patcher.before(target, method, args => {
      lastProps = args?.[0]
      return args
    }))
    register(valenced.patcher.after(target, method, result => {
      const props = lastProps
      lastProps = undefined
      try { return apply(result, props) }
      catch (error) { logger?.warn?.('Skipped incompatible UI node', error); return result }
    }))
    patched.add(target)
  } catch (error) { logger?.warn?.('Could not attach component patch', error) }
}

function addUIHooks(cleanup, logger) {
  const withMemoName = buildMemoName()
  const patched = new WeakSet()
  const keep = fn => {
    if (typeof fn === 'function') cleanup(fn)
  }

  const forComponent = (filter, apply, max = 12) => {
    try {
      keep(valenced.modules.finders.getModules(filter, found => {
        try { attachMemoPatch(found, apply, keep, patched, logger) }
        catch (error) { logger?.warn?.('Module callback failed', error) }
      }, { max }))
    } catch (error) { logger?.warn?.('Could not register module filter', error) }
  }

  // Server members: current Discord commonly uses memoized UserRow components.
  forComponent(withMemoName('UserRow'), (result, props) =>
    (settingsApi?.cache ?? DEFAULTS).memberList ? insertMemberBadge(result, props) : result)
  // Older Discord clients exported GuildMemberRow.
  try {
    keep(valenced.modules.finders.getModules(valenced.modules.finders.filters.withProps('GuildMemberRow'), namespace => {
      attachMemoPatch(namespace?.GuildMemberRow, (result, props) =>
        (settingsApi?.cache ?? DEFAULTS).memberList ? insertMemberBadge(result, props) : result,
        keep, patched, logger)
    }))
  } catch (error) { logger?.warn?.('GuildMemberRow hook unavailable', error) }

  // DM list: Vendetta's MessagesItemChannelContent structure, if still exported.
  const dmPatch = (result, props) => {
    if (!(settingsApi?.cache ?? DEFAULTS).dmList) return result
    const recipients = props?.channel?.recipients
    if (!Array.isArray(recipients) || recipients.length !== 1) return result
    return insertDmBadge(result, recipients[0])
  }
  forComponent(withMemoName('MessagesItemChannelContent'), dmPatch)
  forComponent(valenced.modules.finders.filters.withName('MessagesItemChannelContent'), dmPatch)

  // Profile: same module-path strategy used by more recent Revenge/Valenced ports.
  // The hook is no-op if Discord no longer exports DisplayName.
  try {
    keep(valenced.discord.utils.modules.finders.getModuleWithImportedPath(
      'modules/user_profile/native/UserProfilePrimaryInfo.tsx',
      namespace => {
        try {
          const DisplayName = namespace?.DisplayName
          if (typeof namespace?.default !== 'function' || typeof DisplayName !== 'function') return
          function DisplayNameWithIndicators(props) {
            const orig = valenced.react.React.createElement(DisplayName, props)
            const enabled = (settingsApi?.cache ?? DEFAULTS).profiles
            return enabled && props?.user?.id ? rowWithBadge(orig, props.user.id) : orig
          }
          keep(valenced.patcher.after(namespace, 'default', tree => replaceFirst(
            tree,
            element => element.type === DisplayName,
            element => valenced.react.React.createElement(DisplayNameWithIndicators, {
              ...element.props,
              key: element.key,
            }),
          )))
        } catch (error) { logger?.warn?.('Profile header hook unavailable', error) }
      },
    ))
  } catch (error) { logger?.warn?.('Profile finder unavailable', error) }
}

function SettingsComponent({ api }) {
  const settings = api.jsonStorage.use() ?? DEFAULTS
  const switches = [
    ['dmList', 'DM list', 'Show platforms next to one-to-one DMs'],
    ['memberList', 'Member lists', 'Show platforms beside members in server lists'],
    ['profiles', 'User profiles', 'Show platforms beside usernames on profiles'],
    ['crimsonIcons', 'Crimson icons', 'Match your dark red AMOLED theme instead of presence colors'],
    ['showOffline', 'Show offline platforms', 'Include offline / invisible session indicators if provided'],
  ]
  return valenced.react.React.createElement(
    valenced.discord.design.Design.TableRowGroup,
    { title: 'Platform Indicators' },
    ...switches.map(([key, label, subLabel]) =>
      valenced.react.React.createElement(valenced.discord.design.Design.TableSwitchRow, {
        key, label, subLabel,
        value: Boolean(settings[key]),
        onValueChange: value => api.jsonStorage.set({ ...settings, [key]: value }),
      })),
  )
}

return plugin({
  jsonStorage: { load: true, default: DEFAULTS },
  start({ cleanup, jsonStorage, logger }) {
    settingsApi = jsonStorage
    addUIHooks(cleanup, logger)
    logger?.log?.('Platform Indicators started (experimental). Check UI positions after Discord updates.')
  },
  stop() { settingsApi = undefined },
  SettingsComponent,
})

})()
