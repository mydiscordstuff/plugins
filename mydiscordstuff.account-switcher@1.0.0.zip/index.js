({default:(function () {
  'use strict';
  var KEY = 'mydiscordstuff.account-switcher';
  var unsubs = [];
  var host = null;
  var React = null;
  var RN = null;
  var Store = null;
  var UserStore = null;
  var SwitchActions = null;
  var OpenAccountsModal = null;
  var sheetActions = null;
  var NativeCap = 5;
  var alertFunction = function(title, msg) { console.warn('[ContasRapidas] ' + title + ': ' + msg); };

  function addCleanup(fn) {
    if (typeof fn === 'function') unsubs.push(fn);
  }
  function doCleanup() {
    while (unsubs.length) {
      try { unsubs.pop()(); } catch (_) {}
    }
    Store = UserStore = SwitchActions = OpenAccountsModal = sheetActions = null;
    React = RN = null;
  }
  function getCurrent() {
    try { return UserStore && UserStore.getCurrentUser ? UserStore.getCurrentUser() : null; } catch (_) {return null;}
  }
  function getAccounts() {
    try {
      var users = Store && Store.getUsers && Store.getUsers();
      if (!Array.isArray(users)) return [];
      return users.filter(function(u){return u && typeof u.id === 'string';}).map(function(u){
        return {id:u.id, username:String(u.username||'Conta'), avatar:u.avatar||null, tokenStatus:u.tokenStatus};
      });
    } catch (_) {return [];} 
  }
  function displayName(u) {
    return u.username || 'Conta';
  }
  function showError(title, msg) {
    try {alertFunction(title, msg);} catch (_) {}
  }
  function getIsActive(id) {
    return getCurrent() && getCurrent().id === id;
  }
  function getSwitcherActions() {
    if (SwitchActions && typeof SwitchActions.switchAccount === 'function') return SwitchActions;
    // Re-query lazily in case Discord loads this module only when its account UI is opened.
    try {
      var f = host.modules && host.modules.finders;
      var filter = f && f.filters && f.filters.withProps && f.filters.withProps('switchAccount','removeAccount');
      var found = filter && f.lookupModule && f.lookupModule(filter);
      var ns = Array.isArray(found) && found[0];
      if (ns && typeof ns.switchAccount === 'function') SwitchActions = ns;
      if (ns && ns.default && typeof ns.default.switchAccount === 'function') SwitchActions = ns.default;
    } catch (_) {}
    return SwitchActions;
  }
  async function changeAccount(account) {
    if (!account || !account.id || getIsActive(account.id)) return true;
    var actions = getSwitcherActions();
    if (!actions || typeof actions.switchAccount !== 'function') {
      showError('Troca de conta indisponível', 'Abra sua aba de perfil uma vez e tente novamente. O módulo do Discord ainda não carregou.');
      return false;
    }
    try {
      await actions.switchAccount(account.id);
      return true;
    } catch (_) {
      showError('Não foi possível trocar', 'O Discord rejeitou a sessão dessa conta. Entre novamente pelo gerenciador nativo.');
      return false;
    }
  }
  function resolveManager() {
    if (OpenAccountsModal) return OpenAccountsModal;
    try {
      var f = host.modules && host.modules.finders;
      var filtered = f && f.lookupModule && f.lookupModule(f.filters.withProps('openManageAccountsModal'));
      var m = filtered && filtered[0];
      if (m && typeof m.openManageAccountsModal === 'function') OpenAccountsModal = m.openManageAccountsModal;
    } catch (_) {}
    return OpenAccountsModal;
  }
  function showNativeManager(route) {
    var open = resolveManager();
    if (typeof open !== 'function') {
      showError('Gerenciador não disponível', 'Abra a aba do seu perfil e tente novamente. O Discord ainda não carregou sua tela de contas.');
      return;
    }
    try {open(route || 'MANAGE_ACCOUNTS');}
    catch (_) {showError('Erro', 'Não foi possível abrir a tela de contas do Discord.');}
  }
  function confirmRemoval(a) {
    if (!a || getIsActive(a.id)) return;
    try {
      RN.Alert.alert('Remover conta', 'Remover @' + a.username + ' deste dispositivo? A conta Discord não será excluída.', [
        {text:'Cancelar',style:'cancel'},
        {text:'Remover',style:'destructive',onPress:function(){
          var actions = getSwitcherActions();
          if (!actions || typeof actions.removeAccount !== 'function') return showError('Indisponível','Abra a tela de gerenciar contas para remover esta conta.');
          try {actions.removeAccount(a.id);} catch (_){showError('Erro','Não foi possível remover esta conta.');}
        }}
      ]);
    } catch (_) {}
  }
  function h(type, props) {
    if (!React || !React.createElement) return null;
    var children = Array.prototype.slice.call(arguments,2);
    return React.createElement.apply(React, [type,props].concat(children));
  }
  var crimson = '#CF455B';
  var surface = '#130307';
  function Avatar(u) {
    var fallback = 'https://cdn.discordapp.com/embed/avatars/0.png';
    var uri = u && u.avatar ? 'https://cdn.discordapp.com/avatars/'+encodeURIComponent(u.id)+'/'+encodeURIComponent(u.avatar)+'.png?size=80' : fallback;
    return h(RN.Image,{source:{uri:uri},style:{width:40,height:40,borderRadius:20,backgroundColor:'#270810'}});
  }
  function useLiveAccounts() {
    var result = React.useState(0), setCounter=result[1];
    React.useEffect(function(){
      var listener=function(){setCounter(function(v){return v+1;});};
      var stores=[Store,UserStore].filter(Boolean);
      for(var i=0;i<stores.length;i++)try{stores[i].addChangeListener(listener);}catch(_){}
      return function(){for(var j=0;j<stores.length;j++)try{stores[j].removeChangeListener(listener);}catch(_){}};
    },[]);
    return getAccounts();
  }
  function AccountManagerContent() {
    var accounts = useLiveAccounts();
    var [busy,setBusy] = React.useState(null);
    var current=getCurrent();
    var accentText={color:crimson,fontSize:14};
    function accountRow(a) {
      var currentAccount=current && a.id===current.id;
      var invalid=a.tokenStatus===0;
      var selected=busy===a.id;
      return h(RN.Pressable,{key:a.id,disabled:busy!==null||currentAccount||invalid,onPress:async function(){
        setBusy(a.id);
        var success=await changeAccount(a);
        setBusy(null);
        if(success)try{sheetActions && sheetActions.hideActionSheet();}catch(_){}
      },style:{padding:12,marginBottom:8,borderRadius:14,borderColor:currentAccount?'#278D58':'#531523',borderWidth:1,backgroundColor:surface,flexDirection:'row',alignItems:'center',gap:12}},
        Avatar(a),
        h(RN.View,{style:{flex:1}},
          h(RN.Text,{style:{fontSize:16,fontWeight:'600',color:'#F0B5BD'}},displayName(a)),
          h(RN.Text,{style:accentText},currentAccount?'✓ Conta ativa':invalid?'Sessão expirada — faça login novamente':selected?'Trocando...':'Toque para trocar')
        ),
        h(RN.Text,{style:{fontSize:19,color:currentAccount?'#36BC7C':crimson}},currentAccount?'✓':'›')
      );
    }
    return h(RN.ScrollView,{contentContainerStyle:{padding:16,paddingBottom:40},keyboardShouldPersistTaps:'handled'},
      h(RN.Text,{style:{fontSize:20,fontWeight:'700',color:crimson,marginBottom:5}},'Trocar de conta'),
      h(RN.Text,{style:{color:'#CF8693',fontSize:12,marginBottom:18}},'Suas sessões são gerenciadas pelo próprio Discord.'),
      accounts.length ? accounts.map(accountRow) : h(RN.Text,{style:{color:'#D6A0AB',padding:14}},'Nenhuma conta adicional salva ainda.'),
      h(RN.Pressable,{onPress:function(){try{sheetActions&&sheetActions.hideActionSheet();}catch(_){} showNativeManager('LOGIN');},style:{padding:14,backgroundColor:'#6E1029',borderRadius:12,marginTop:8}},
        h(RN.Text,{style:{color:'#FFE3E9',fontSize:15,fontWeight:'700',textAlign:'center'}},'+ Adicionar conta')),
      h(RN.Pressable,{onPress:function(){try{sheetActions&&sheetActions.hideActionSheet();}catch(_){} showNativeManager('MANAGE_ACCOUNTS');},style:{padding:14,borderWidth:1,borderColor:'#6E1029',borderRadius:12,marginTop:10}},
        h(RN.Text,{style:{color:crimson,fontSize:15,fontWeight:'700',textAlign:'center'}},'Gerenciar contas')),
      h(RN.Text,{style:{color:'#B47580',fontSize:12,lineHeight:18,marginTop:18}},'Limite do Discord: até '+NativeCap+' contas no gerenciador nativo. Nenhum token ou senha é armazenado por este plugin.')
    );
  }
  function SettingsComponent() { return h(AccountManagerContent,null); }
  function openSwitcher() {
    try {
      sheetActions = host.discord && host.discord.actions && host.discord.actions.ActionSheetActionCreators;
      var design = host.discord && host.discord.design && host.discord.design.Design;
      if (sheetActions && typeof sheetActions.openLazy==='function' && design && design.ActionSheet) {
        function Sheet(){
          var header = design.BottomSheetTitleHeader ? h(design.BottomSheetTitleHeader,{title:'Contas Rápidas'}) : null;
          return h(design.ActionSheet,{header:header},h(AccountManagerContent,null));
        }
        sheetActions.openLazy(Promise.resolve({default:Sheet}),'mydiscordstuff-account-switcher',{});
        return;
      }
    } catch (_) {}
    // Fallback to Discord's official account manager when the sheet API changed.
    showNativeManager('MANAGE_ACCOUNTS');
  }
  function bindModuleImports() {
    try {
      var finder=host.discord && host.discord.utils && host.discord.utils.modules && host.discord.utils.modules.finders;
      if (!finder || typeof finder.getModuleWithImportedPath!=='function') return;
      addCleanup(finder.getModuleWithImportedPath('modules/multi_account/MultiAccountActionCreators.tsx',function(ns){
        SwitchActions=(ns && ns.default && typeof ns.default.switchAccount==='function')?ns.default:ns;
      }));
      addCleanup(finder.getModuleWithImportedPath('modules/multi_account/native/openManageAccountsModal.tsx',function(ns){
        if(ns && typeof ns.default==='function') OpenAccountsModal=ns.default;
      }));
    } catch (_) {}
  }
  function patchMobileGate() {
    try {
      var p=host.patcher;
      var store=Store;
      if(!store||!p||typeof p.after!=='function')return;
      var proto=Object.getPrototypeOf(store);
      if(proto && typeof proto.getCanUseMultiAccountMobile==='function') {
        addCleanup(p.after(proto,'getCanUseMultiAccountMobile',function(){return true;}));
      } else if(typeof store.getCanUseMultiAccountMobile==='function'){
        addCleanup(p.after(store,'getCanUseMultiAccountMobile',function(){return true;}));
      }
      try{store.emitChange&&store.emitChange();}catch(_){}
    }catch(_){}
  }
  function installSettings() {
    var settingAPI=host.discord&&host.discord.modules&&host.discord.modules.settings;
    if(!settingAPI) return;
    var createSetting=function(){
      try {
        var setting={
          parent:null,
          type:'pressable',
          useTitle:function(){return 'Trocar de conta';},
          useDescription:function(){return 'Contas Rápidas • Discord nativo';},
          IconComponent:function(){return h(RN.Text,{style:{fontSize:26,color:crimson}},'⇄');},
          onPress:openSwitcher
        };
        var unreg=settingAPI.registerSettingsItem(KEY,setting);
        addCleanup(unreg);
        addCleanup(settingAPI.addSettingsItemToSection('VALENCED',KEY,-1));
        if(settingAPI.refreshSettings)settingAPI.refreshSettings();
      }catch(e){
        try{host.logger&&host.logger.error&&host.logger.error('[ContasRapidas] Settings registration failed '+String(e));}catch(_){}
      }
    };
    if(settingAPI.onSettingsModulesLoaded) {
      addCleanup(settingAPI.onSettingsModulesLoaded(createSetting));
    } else createSetting();
  }
  function start(api) {
    host=valenced;
    React=host.react&&host.react.React;
    RN=host.react&&host.react.ReactNative;
    if(!React||!RN) throw new Error('React unavailable in Valenced start phase');
    Store=host.discord && host.discord.flux && host.discord.flux.Stores && host.discord.flux.Stores.MultiAccountStore;
    UserStore=host.discord && host.discord.flux && host.discord.flux.Stores && host.discord.flux.Stores.UserStore;
    try { alertFunction=RN.Alert.alert.bind(RN.Alert); }catch(_){}
    bindModuleImports();
    patchMobileGate();
    installSettings();
    if(api && api.cleanup) api.cleanup(doCleanup);
  }
  return plugin({ start:start, stop:doCleanup, SettingsComponent:SettingsComponent });
})()})
