({default:(function(){
  'use strict';
  // OrionQuests Mobile — restricted, independently written partial port.
  // Only WATCH_VIDEO_ON_MOBILE / WATCH_VIDEO via Discord's own quest action.
  // Disabled until explicit consent; does not spoof desktop games or streams.
  var host=null,React=null,RN=null,cleanups=[],actionsCache=null,storeCache=null,timer=null,runId=0,subscribers=new Set(),lastAccount=null;
  var st={status:'parado',questId:null,questName:null,message:'Toque em Iniciar para começar.',sent:0,startedAt:0};
  var C={bg:'#000000',surface:'#19050A',border:'#4B1523',accent:'#CE5265',text:'#F2B2BF',muted:'#BA7D89'};
  function h(){return React&&React.createElement?React.createElement.apply(React,arguments):null;}
  function emit(){subscribers.forEach(function(fn){try{fn();}catch(_){}});}
  function set(p){Object.assign(st,p);emit();}
  function getState(){return Object.assign({},st);}
  function lookup(names){try{var f=host&&host.modules&&host.modules.finders;if(!f)return null;for(var i=0;i<names.length;i++){var filter=f.filters&&f.filters.withProps&&f.filters.withProps.apply(null,names[i]),m=filter&&f.lookupModule&&f.lookupModule(filter),v=Array.isArray(m)&&m[0];if(v){if(v.default&&names[i].every(function(n){return typeof v.default[n]!=='undefined';}))return v.default;return v;}}}catch(_){}return null;}
  function stores(){return host&&host.discord&&host.discord.flux&&host.discord.flux.Stores||{};}
  function userId(){try{var s=stores().UserStore;return s&&s.getCurrentUser&&s.getCurrentUser().id||null;}catch(_){return null;}}
  function questStore(){return stores().QuestsStore||storeCache||lookup([['getQuest','getQuestConfig']]);}
  function questActions(){return actionsCache||lookup([['updateVideoProgress','enrollInQuest'],['updateVideoProgress']]);}
  function entries(v){if(v instanceof Map)return Array.from(v.values());return Array.isArray(v)?v:v&&typeof v==='object'?Object.values(v):[];}
  function currentTask(q){
    if(!q||!q.config)return null;
    var stat=q.userStatus||q.user_status||{},conf=q.config||{};
    if(!stat.enrolledAt&&!stat.enrolled_at)return null;
    if(stat.completedAt||stat.completed_at||stat.claimedAt||stat.claimed_at)return null;
    var tasks=((conf.taskConfigV2||conf.task_config_v2||conf.taskConfig||conf.task_config)||{}).tasks||{};
    var prog=stat.progress||{},keys=['WATCH_VIDEO_ON_MOBILE','WATCH_VIDEO'];
    for(var i=0;i<keys.length;i++){var key=keys[i],t=tasks[key];if(!t||!Number.isFinite(Number(t.target)))continue;
      var p=prog[key];var done=Number(p&&typeof p==='object'?p.value:p)||0,goal=Number(t.target);if(goal>done&&goal>0)return {key:key,goal:goal,done:Math.max(0,done),name:String((conf.messages||{}).questName||(conf.messages||{}).quest_name||q.id)};
    }return null;
  }
  function allJobs(){var store=questStore();if(!store)return [];
    var map=new Map();entries(store.quests).forEach(function(q){if(q&&q.id)map.set(q.id,q);});
    var result=[];map.forEach(function(q){var task=currentTask(q);if(task)result.push({id:q.id,task:task});});return result;
  }
  function foreground(){return !RN||!RN.AppState||RN.AppState.currentState==='active';}
  function clear(){if(timer!==null){clearTimeout(timer);timer=null;}}
  function stop(msg){++runId;clear();set({status:'parado',questId:null,questName:null,message:msg||'Parado.',startedAt:0,sent:0});}
  function pause(){if(st.status!=='executando')return;clear();set({status:'pausado',message:'Pausado por você. Nenhum progresso será enviado.'});}
  function start(){var me=userId();if(!me){set({message:'Entre em uma conta do Discord primeiro.'});return false;}
    if(!questActions()||typeof questActions().updateVideoProgress!=='function'){set({message:'Ação de vídeo indisponível. Abra Missões no Discord antes.'});return false;}
    var jobs=allJobs();if(!jobs.length){set({message:'Nenhuma missão de vídeo aceita e incompleta foi encontrada.'});return false;}
    ++runId;clear();lastAccount=me;set({status:'executando',message:'Processando missões de vídeo (Discord em primeiro plano).'});schedule(runId,200);return true;
  }
  function resume(){if(st.status==='pausado')return start();if(st.status==='executando')return true;return start();}
  function schedule(token,ms){clear();timer=setTimeout(function(){void tick(token);},ms);}
  async function tick(token){if(token!==runId||st.status!=='executando')return;
    if(userId()!==lastAccount){stop('Conta mudou; automação interrompida.');return;}
    if(!foreground()){pause();set({message:'App saiu de primeiro plano. Toque em Retomar ao voltar.'});return;}
    var jobs=allJobs();if(!jobs.length){stop('Nenhuma missão de vídeo pendente; consulte o QuestUI.');return;}
    var picked=jobs[0],job=picked.task,id=picked.id;
    // Never advance faster than elapsed foreground time. Resuming a job resets local clock.
    if(st.questId!==id){set({questId:id,questName:job.name,startedAt:Date.now(),sent:Math.max(0,job.done)});}
    var age=Math.max(0,(Date.now()-st.startedAt)/1000),target=Math.min(job.goal,Math.max(job.done,Math.min(st.sent+6,job.done+age)));
    if(target<=job.done+0.5){schedule(token,6000);return;}
    try{
      var a=questActions();if(!a||typeof a.updateVideoProgress!=='function')throw Error('Ação de vídeo não disponível.');
      // The Discord client signs this request; we never read or send account tokens ourselves.
      await a.updateVideoProgress(id,target);
      if(token!==runId||st.status!=='executando')return;
      set({sent:target,message:job.name+' • '+Math.floor(target)+' / '+Math.floor(job.goal)+' s'});
      schedule(token,6000);
    }catch(e){pause();set({message:'Discord recusou ou falhou: '+String(e&&e.message||e).slice(0,140)+'. Verifique a missão antes de continuar.'});}
  }
  var bridge={start:start,stop:stop,pause:pause,resume:resume,getState:getState,subscribe:function(fn){subscribers.add(fn);return function(){subscribers.delete(fn);};}};
  function txt(v,style){return h(RN.Text,{style:Object.assign({color:C.text,fontSize:15},style||{})},String(v));}
  function btn(v,callback,destructive){return h(RN.Pressable,{onPress:callback,style:{padding:14,borderRadius:11,backgroundColor:destructive?'#330710':'#641226',marginTop:10,borderWidth:1,borderColor:C.border}},txt(v,{fontWeight:'700',textAlign:'center'}));}
  function askStart(){try{RN.Alert.alert('Atenção: automação de missões','Discord pode restringir quests ou registrar infrações na conta por automação. Esta versão só tenta missões WATCH_VIDEO e WATCH_VIDEO_ON_MOBILE, enquanto Discord está aberto. Continuar?', [{text:'Cancelar',style:'cancel'},{text:'Concordo e iniciar',onPress:start}]);}catch(_){set({message:'Não foi possível mostrar a confirmação.'});}}
  function Panel(){var hook=React.useState(0),refresh=hook[1];React.useEffect(function(){return bridge.subscribe(function(){refresh(function(v){return v+1;});});},[]);
    var jobs=allJobs(),body=[txt('OrionQuests • Mobile',{fontSize:24,fontWeight:'bold',marginBottom:7}),txt('Port experimental: apenas tarefas de vídeo compatíveis com Android.',{color:C.muted,fontSize:12,marginBottom:12}),txt('Estado: '+st.status,{fontWeight:'700'}),txt(st.message,{color:C.muted,marginTop:7}),txt('Missões de vídeo elegíveis: '+jobs.length,{marginTop:12}),btn('▶ Iniciar',askStart,false),btn('⏸ Pausar',pause,true),btn('↻ Retomar',function(){if(st.status==='pausado')askStart();},false),btn('■ Parar',function(){stop('Parado por você.');},true)];
    jobs.forEach(function(job){body.push(h(RN.View,{key:job.id,style:{borderWidth:1,borderColor:C.border,backgroundColor:C.surface,borderRadius:10,padding:12,marginTop:10}},txt(job.task.name,{fontWeight:'600'}),txt(job.task.key+' · '+Math.floor(job.task.done)+'/'+Math.floor(job.task.goal)+' s',{color:C.muted,fontSize:12})));});
    body.push(txt('Jogos de PC, transmissão, consoles e conquistas de atividades não são suportados neste port. Nunca fornece tokens nem pede senha.',{fontSize:12,color:C.muted,marginTop:14,lineHeight:18}));
    return h(RN.ScrollView,{style:{flex:1,backgroundColor:C.bg},contentContainerStyle:{padding:16,paddingBottom:40}},...body);
  }
  function SettingsComponent(){return h(Panel,{});}
  function openPanel(){try{var a=host.discord.actions.ActionSheetActionCreators,d=host.discord.design.Design;if(a&&a.openLazy&&d&&d.ActionSheet){function Sheet(){return h(d.ActionSheet,{header:d.BottomSheetTitleHeader?h(d.BottomSheetTitleHeader,{title:'OrionQuests Mobile'}):null},h(Panel,{}));}a.openLazy(Promise.resolve({default:Sheet}),'mydiscordstuff.orion.mobile.sheet',{});return;}}catch(_){}try{RN.Alert.alert('OrionQuests','Abra Plugins → OrionQuests → Configurações.');}catch(_){} }
  function register(){var a=host.discord&&host.discord.modules&&host.discord.modules.settings;if(!a||!a.registerSettingsItem)return;
    function go(){try{var id='mydiscordstuff.orionquests.mobile';cleanups.push(a.registerSettingsItem(id,{parent:null,type:'pressable',useTitle:function(){return 'OrionQuests • Mobile';},useDescription:function(){return 'Vídeo: iniciar, pausar e parar';},IconComponent:function(){return h(RN.Text,{style:{fontSize:23,color:C.accent}},'▶');},onPress:openPanel}));cleanups.push(a.addSettingsItemToSection('VALENCED',id));a.refreshSettings&&a.refreshSettings();}catch(e){set({message:'Falha ao registrar menu: '+String(e)});}}
    if(a.onSettingsModulesLoaded)cleanups.push(a.onSettingsModulesLoaded(go));else go();
  }
  function cleanup(){stop('Plugin desligado.');while(cleanups.length){try{cleanups.pop()();}catch(_){}}if(globalThis.__mydiscordstuffOrionMobileBridge===bridge)delete globalThis.__mydiscordstuffOrionMobileBridge;}
  return plugin({start:function(api){host=valenced;React=host.react&&host.react.React;RN=host.react&&host.react.ReactNative;if(!React||!RN)throw Error('React Native indisponível');globalThis.__mydiscordstuffOrionMobileBridge=bridge;register();if(api.cleanup)api.cleanup(cleanup);},stop:cleanup,SettingsComponent:SettingsComponent});
})()})
